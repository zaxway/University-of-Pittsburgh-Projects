#include "types.h"
#include "defs.h"
#include "param.h"
#include "user.h"
#include "memlayout.h"
#include "mmu.h"
#include "stat.h"
#include "proc.h"
#include "spinlock.h"
#include "pstat.h"

int main(int argc, char *argv[]) {
  settickets(30);
  int pid = fork();
  if (pid == 0) {
    while(1);
  }

  settickets(20);
  pid = fork();
  if (pid == 0) {
    while(1);
  }

  settickets(10);
  pid = fork();
  if (pid == 0) {
    while(1);
  }

  while(1) {
    struct pstat stat;
    getpinfo(&stat);
    for (int i = 0; i < NPROC; i++) {
      if (stat.inuse[i] == 1) {
        printf(0, ":Ticks:")
      }
    }
  }

}
