package com.example.mohitjain.testfile;

import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.widget.Switch;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;

public class TriviaGame extends AppCompatActivity {

    public static ArrayList<String> wordList = new ArrayList<String>();
    public static ArrayList<String> definitionList = new ArrayList<String>();
    public static ArrayList<wordObj> objectList = new ArrayList<wordObj>();
    public static PrintStream out;
    public static PrintStream out2;
    public static int wordCount = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia_game);
        try {
            out = new PrintStream(openFileOutput("example.txt", MODE_APPEND));
            Log.i("ReadFile", "WroteToFile");
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            Log.i("FileNotFound", "FileNotFound");
        }
        try {
            out2 = new PrintStream(openFileOutput("scoreHistory.txt", MODE_APPEND));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        final Switch sw = (Switch) findViewById(R.id.switch1);
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.power);
        sw.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if(sw.isChecked()) {
                    mp.start();
                }
                else {
                    mp.stop();
                }
            }
            });
    }

    public void playButton(View view) {
        Intent x = new Intent(this, playActivity.class);
        startActivity(x);
    }

    public void wordButton(View view) {
        Intent y = new Intent(this, wordActivity.class);
        startActivity(y);
    }

    public void historyButton(View view) {
        Intent z = new Intent(this, historyActivity.class);
        startActivity(z);
    }


//    public void musicSwitch(View view) {
//            MediaPlayer mp = MediaPlayer.create(this, R.raw.power);
//            Switch sw = (Switch) findViewById(R.id.switch1);
//            if (sw.isChecked()) {
//                mp.start();
//            }
//            if (sw.isChecked() == false) {
//                mp.stop();
//            }
//    }
}
