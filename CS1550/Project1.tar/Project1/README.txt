For this project, I did not implement the driver, which was the snake program.
I, however, implemented all the syscalls required as per said for the Project
description. 

graphics.c is the main file for which I implemented all my methods.

spinlock.c is just a helper file provided by the list of xv6 files. 